import axios from "axios";
import config from "../config.js";
import _ from 'lodash';
const LBS = 453.592;

class DeliverightApi {
  constructor(DELIVERIGHT_ID, DELIVERIGHT_SECRET) {
    // Deliveright endpoints
    this.url = `${config.deliverightApi}/api/shopify/store?client_id=${DELIVERIGHT_ID}&client_secret=${DELIVERIGHT_SECRET}`;
    this.shippingUrl = `${config.deliverightApi}/api/shipping?client_id=${DELIVERIGHT_ID}&client_secret=${DELIVERIGHT_SECRET}`;
    this.newOrderUrl = `${config.deliverightApi}/api/shopify/order?client_id=${DELIVERIGHT_ID}&client_secret=${DELIVERIGHT_SECRET}`;
  }

  createStore(data) {
    return new Promise((resolve, reject) => {
      let config = {
        method: "post",
        url: this.url,
        headers: { "Content-Type": "application/json" },
        data,
      };
      axios(config)
        .then((res) => {
          if (res.data)
            resolve({
              name: res.data.data.first_name + " " + res.data.data.last_name,
              first_name: res.data.data.first_name,
              last_name: res.data.data.last_name,
              address: res.data.data.address,
              company: res.data.data.company,
              status: 200,
            });
          else {
            reject({ error: true });
          }
        })
        .catch((err) => {
          try {
            reject(err.response.data);
          } catch {
            reject({ error: true });
          }
        });
    });
  }

  getStore(id) {
    return new Promise((resolve, reject) => {
      console.log(id)
      let config = {
        method: "get",
        url: this.url + `&identifier=${id}`,
        headers: {  }
      };
      axios(config)
        .then((res) => {
          if (res.data.data) {
            resolve({
              name: res.data.data.first_name + " " + res.data.data.last_name,
              company: res.data.data.company,
              first_name: res.data.data.first_name,
              last_name: res.data.data.last_name,
              email: res.data.data.label_recipients[0].contact,
              address: res.data.data.address,
              status: 200,
              settings: res.data.data.shopify_settings,
              pricing_type: res.data.data.default_pricing_set_type
            });
          } else
            reject({
              message: "Store doesn't exist",
              status: 400,
            });
        })
        .catch((err) => {
          try {
            reject(err.response.data); 
          } catch {
            reject({ error: true });
          }
        });
    });
  }

  async updateStore(id, data={}){
    data.store_id = id
    let config = {
      method: "patch",
      url: this.url,
      headers: { "Content-Type": "application/json" },
      data,
    }
    const res = await axios(config)
    return res
  }

  calculateShippingRate(IDENTIFIER, data, serviceLevel, retailer) {
    return new Promise((resolve, reject) => {
      //console.log(data);
      const DESTINATION = data.rate.destination;
      const ORIGIN = data.rate.origin;
      const PRICING_TYPE = retailer.pricing_type || '1'
      let WEIGHT = 0;
      let WEIGHT_PER_ITEM = ''

      // Sum all weights
      for (let product of data.rate.items) {
        WEIGHT += product.grams * product.quantity;
        WEIGHT_PER_ITEM += `&item_weight=${product.grams * product.quantity/LBS}`
      }
      // Grams to pounds (lbs)
      WEIGHT = WEIGHT / LBS;
      var config = {
        method: "get",
        url: `${this.shippingUrl}&steps=1&retailer_identifier=${IDENTIFIER}&zip=${DESTINATION.postal_code}&weight=${WEIGHT}&pickup_region=${ORIGIN.postal_code}&service_level=${serviceLevel}&pricing_type=${PRICING_TYPE}${WEIGHT_PER_ITEM}`,
        headers: {
          "Content-Type": "application/json",
        },
      };

      console.log(`Rate Url: ${config.url}`);

      axios(config)
        .then((res) => {
          if (!res.data.data.errorCode) {
            let shippingResult = res.data.data
            if (!shippingResult || !shippingResult.cost) return reject('Calculator was not able to calculate cost')
            const price = this.formatPrice(this.getPriceByPaymentType(this.sumAccessorials(shippingResult), retailer.settings), retailer.settings);
            resolve(price)
          }
          else reject(res.data.data)
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  async newOrder(data, store, store_id) {

    let order = await this.createDeliverightOrder(data, store, store_id);

    const config = {
      method: "post",
      url: this.newOrderUrl,
      headers: { "Content-Type": "application/json" },
      data: order,
    };
    try {
      const res = await axios(config);
      console.log("Order Sent");
      console.log(res.data);
    } catch (e) {
      console.error("Error at sending order", JSON.stringify(e));
    }
  }

  async createDeliverightOrder(data, retailer, store_id) {
    const LAST_MILE_ONLY = 1

    let is_fob;
    if (retailer.settings.delivery_type == LAST_MILE_ONLY) is_fob = true
    else is_fob = false

    let line_items = [];

    for (let line_item of data.line_items) {
      let drl_item = {
        sku: line_item.sku || line_item.product_id,
        name: line_item.title,
        quantity: line_item.quantity,
        retail_value: line_item.price,
        weight: line_item.grams / LBS,
        // "cube":
        vendor: line_item.vendor,
        // "tracking_number": "489042301",
        freight_info: {
          "is_fob": is_fob,
          vendor_info: {
            first_name: "",
            last_name: "",
            address: {
              address1: line_item.origin_location.address1,
              address2: line_item.origin_location.address2,
              city: line_item.origin_location.city,
              state: line_item.origin_location.province_code,
              zip: line_item.origin_location.zip
            },
            company: line_item.origin_location.name,
            phone: line_item.origin_location.phone,
            email: "",
            receiving_hours: ""
          }
        }
      };

      line_items.push(drl_item);
    }

    let order = {
      order: {
        source: "shopify",
        sales_order_number: data.name,
        ref_order_number: data.id,
        payload: { shopify_order_number: data.order_number, shopify_raw: data },
        customer: {
          first_name: data.customer.first_name,
          last_name: data.customer.last_name,
          address: {
            address1: data.customer_address.address1,
            address2: data.customer_address.address2,
            city: data.customer_address.city,
            state: data.customer_address.province_code,
            zip: data.customer_address.zip
          },
          company: "",
          phone1: {
            number: data.customer_address.phone,
          },
          email: data.customer.email,
        },
        line_items: line_items,
        retailer: {
          identifier: store_id
        },
        service_level: data.shipping_lines[0].code,
        send_retailer_confirmation: false,
        // "expected_arrival_date": "",
        note: "",
        label_recipients: []
      },
      options: {
        send_retailer_confirmation: true,
        send_labels_to_manufacturer: true
      }
    };


    return order;

  }

  getPriceByPaymentType(price, settings){
    const type = settings.payment.type
    console.log(type)
      switch (type){
        case config.paymentStrategies.PAID_BY_CUSTOMER:
          return price
        case config.paymentStrategies.PAID_BY_SHIPPER:
          return 0
        case config.paymentStrategies.SPLIT:
          return (price/100) * (100 - settings.payment.split_ratio)
        case config.paymentStrategies.FIXED:
          let fixedInCents = settings.payment.fixed * 100
          return (price - fixedInCents)
        case config.paymentStrategies.ROUND_NEAREST_NUMBER:
          let diff = 100000
          let p;
          settings.payment.round_nearest.map(num => {
            if ((num > price) && ((num - price) < diff)) {
              p = num
              diff = num - price
            }
          })
          if (!p) p = price
          return p
      }
  }

  sumAccessorials(shippingResult){
    // Adding fees
    console.log(`Shopify Shipping Response: ${JSON.stringify(shippingResult)}`)
    let price = shippingResult.cost + _.sumBy(_.toArray(shippingResult.accessorial_fees),'cost')
    // Return price in cents
    return price
  }

  formatPrice(price, settings){
    // Formatting price to be in cents
    if (settings.payment.limit.active && settings.payment.limit.amount) price = _.min([price, settings.payment.limit.amount])
    return price * 100
  }
};


const { DELIVERIGHT_ID, DELIVERIGHT_SECRET } = process.env;
export default new DeliverightApi(DELIVERIGHT_ID, DELIVERIGHT_SECRET);
// deliveright.updateStore('shai-drai-test.myshopify.com', {auth: {access_token: "test5"}})