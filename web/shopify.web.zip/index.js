// @ts-check
import { join } from "path";
import { readFileSync } from "fs";
import express from "express";
import serveStatic from "serve-static";

import shopify from "./shopify.js";
import GDPRWebhookHandlers from "./webhook_handlers/gdpr.js";
import OrderWebhookHandlers from "./webhook_handlers/order.js";

import deliveright from "./classes/deliveright.js"
import onInstallApp from "./utils/onInstallApp.js"
import createCarrier from "./utils/createCarrier.js"
import config from "./config.js";
import * as util from "util";
import isCarrierConfigured from "./utils/isCarrierConfigured.js";
import filterDeliverightProducts from "./utils/filterDeliverightProducts.js";
import dotenv from "dotenv"

dotenv.config({path: './../.env'})

const PORT = process.env.BACKEND_PORT || process.env.PORT;

const STATIC_PATH =
  process.env.NODE_ENV === "production"
    ? `${process.cwd()}/frontend/dist`
    : `${process.cwd()}/frontend/`;

const app = express();

const onInstallAppMiddleware = async (_req, res, next) => {
  const session = res.locals.shopify.session
  try {
    await onInstallApp(session)
    next()
  } catch(e) {
    console.error(e)
    res.status(400).send({error: { message: "An error has occurred, please try again." }})
  }
}
// Set up Shopify authentication and webhook handling
app.get(shopify.shopify.config.auth.path, shopify.shopify.auth.begin());
// app.get(
//   shopify.shopify.config.auth.callbackPath,
//   shopify.shopify.auth.callback(),
//     onInstallAppMiddleware,
//   shopify.shopify.redirectToShopifyOrAppRoot()
// );

app.get(shopify.shopify.config.auth.callbackPath, 
  shopify.shopify.auth.callback(), 
  (req, res) => {
    console.log("Session is set: ", req.session);
    res.redirect("/"); // Redirige a donde quieres después de la autenticación
  });


app.post(
  shopify.shopify.config.webhooks.path,
  shopify.shopify.processWebhooks({
    webhookHandlers:
        {...GDPRWebhookHandlers, ...OrderWebhookHandlers}
  })
);

// If you are adding routes outside of the /api path, remember to
// also add a proxy rule for them in web/frontend/vite.config.js

app.use("/api/*", shopify.shopify.validateAuthenticatedSession());

app.use(express.json());
app.get("/api/check", async (req, res) => {
  const shop = req.query.shop;
  const isOnline = false;
 
  try {
    const installed = await shopify.api.auth.ensureInstalledOnShop(shop, isOnline);
    res.status(200).json({ installed });
  } catch (err) {
    console.error("Error checking installation:", err);
    res.status(500).json({ error: "Something went wrong" });
  }
});

app.post("/api/store", async (_req, res) => {
  const session = res.locals.shopify.session;
  const shop_data = {..._req.body, store_id: session.shop}
  try {
    let createRes = await deliveright.createStore(shop_data);
    if (createRes) {

      await onInstallApp(session)
      res.status(200).send(createRes)
    }
  } catch (err) {
    try {
      console.error(err)
      res.status(parseInt(err.status)).send(err);
    } catch {
      res.status(400).send({error: { message: "An error has occurred, please try again." }})
    }
  }
});


app.get("/api/store", async (_req, res) => {
  let status = 200;
  let response = {};
  let session = res.locals.shopify.session
  const { shop } = session;
  try {
    let result = await deliveright.getStore(shop);
    if (result) {
      let carrier = await isCarrierConfigured(session)
      result.carrier = !!carrier
      response = result
    } else {
      status = 400;
      response.error = "Retailer not found in Grasshopper"
    }
  } catch (err) {
    if (err.response) {
      status = err.response.status;
      response.error = JSON.stringify(err.response.statusText);
    } else {
      response.error = JSON.stringify(err);
      status = 400;
    }
  }
  res.status(status).send(response);
});

app.post("/carrier", async (_req, res) => {
  try {
    let rates = []
    const IDENTIFIER = _req.headers['x-shopify-shop-domain'];
    const retailer = await deliveright.getStore(IDENTIFIER)
    const session = {
      shop: IDENTIFIER,
      accessToken: retailer.settings.auth.access_token,
    };
    const LAST_MILE_ONLY = 1
    if (retailer.settings.delivery_type == LAST_MILE_ONLY) _req.body.rate.origin.postal_code = 'fob'

    let filtered_items = await filterDeliverightProducts(shopify, session, _req.body.rate.items)
    let filtered_request = {rate: {..._req.body.rate, items: filtered_items}}
    if (filtered_request.rate.items.length > 0) {
      let all_tags = filtered_request.rate.items.flatMap(i => i.tags)
      const service_levels = [...new Set(all_tags)];

      for (let s of service_levels) {
        console.log(`Shopify shipping request: Origin:${_req.body.rate.origin.postal_code}; Destination:${_req.body.rate.destination.postal_code}; Service Level:${s}; Account: ${retailer.company};
         Items: ${JSON.stringify(_req.body.rate.items)})`);

        if (!config.serviceLevels[s]) {
          console.log(`Service level ${s} is not supported; skip`)
          continue;
        }

        let totalPrice = null
        try {
          totalPrice = await deliveright.calculateShippingRate(IDENTIFIER, filtered_request, s, retailer);
          console.log(`RATE RESPONSE: ${totalPrice}`);
        } catch (err) {
          console.error(`RATE RESPONSE ERROR: ${JSON.stringify(err)}`)
        }
        config.serviceLevels[s].total_price = totalPrice
        rates.push(config.serviceLevels[s])

      }
    }
    res.status(200).send({rates});
  } catch (err){
    console.error(err)
    res.status(400).send();
  }
});

app.get("/health", async (_req, res  ) => {
  res.status(200).send("ok")
})

app.get("/api/carrier/activate", async (_req, res) => {
  try {
    const session = res.locals.shopify.session
    await createCarrier(session)
    res.status(200).send()
  }
  catch (error) {
    res.status(400).send(error)
  }
})


app.use(serveStatic(STATIC_PATH, { index: false }));

app.use("/*", async (_req, res) => {
  return res
    .status(200)
    .set("Content-Type", "text/html")
    .send(readFileSync(join(STATIC_PATH, "index.html")));
});

app.listen(PORT);