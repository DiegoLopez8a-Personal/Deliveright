import {DeliveryMethod} from "@shopify/shopify-api";
import deliveright from "../classes/deliveright.js";
import shopify from "../shopify.js";
import config from "../config.js";
import filterDeliverightProducts from "../utils/filterDeliverightProducts.js";

const update_line_items_location = async (session, payload) => {
  return await Promise.all(
      payload.fulfillments
          .filter(f => f.status === "success") // Filter for successful fulfillments
          .map(async (fulfillment) => {
            try {
              // Fetch the location using the location_id from the fulfillment
              const origin = await shopify.api.rest.Location.find({
                session,
                id: fulfillment.location_id
              });

              // If the origin location exists, update the corresponding line items
              if (origin) {
                // Ensure we're matching line items correctly and updating the location
                fulfillment.line_items.forEach((lineItem) => {
                  const lineItemIndex = payload.line_items.findIndex(
                      (li) => li.id === lineItem.id
                  );

                  // If a matching line item is found, update its origin_location
                  if (lineItemIndex !== -1) {
                    payload.line_items[lineItemIndex].origin_location = origin;
                    console.log(`Updated location for line item ${lineItem.id} to ${origin.name}`);
                  } else {
                    console.warn(`No matching line item found for ID ${lineItem.id}`);
                  }
                });
              } else {
                console.warn(`No origin location found for fulfillment ID ${fulfillment.id}`);
              }
            } catch (error) {
              console.trace(`Error fetching location for fulfillment ID ${fulfillment.id}:`, JSON.stringify(error));
            }
          })
  );
}

const orders_fulfilled_callback = async (topic, shop, body, webhookId) => {
      let payload = JSON.parse(body);
      try {
        // Get the carrier service chosen by the customer
        const store = await deliveright.getStore(shop);
        const session = {shop,
          accessToken: store.settings.auth.access_token
        }
        const customerCarrierCode = payload.shipping_lines?.[0]?.code;
        let isDeliverightOrder = !!config.serviceLevels[customerCarrierCode]
        //
        if (isDeliverightOrder) {
          console.log("ACCEPTED: Deliveright order");
          let origin;
          try {
            await update_line_items_location(session, payload)

            payload.customer_address = payload.customer?.default_address || payload.shipping_address;

            let filtered_items = await filterDeliverightProducts(shopify, session, payload.line_items)
            payload = {...payload, line_items: filtered_items}

          } catch (e) {
            console.error('No multiple originations found', e)
          }

          //
          await deliveright.newOrder(payload, store, shop);
        } else {
          console.log("REJECTED: Not Deliveright order");
        }
      } catch (e) {
        console.error('Order creation exception', e)
        console.error('Shopify order creation req on exception', payload)
        console.error('WebhookId = ', webhookId)
      }
    }

export default {
  ORDERS_FULFILLED: {
    deliveryMethod: DeliveryMethod.Http,
    callbackUrl: "/api/webhooks",
    callback: orders_fulfilled_callback
  },
};
