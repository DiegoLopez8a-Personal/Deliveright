import deliveright from "../classes/deliveright.js"
import createCarrier from "./createCarrier.js"

export default async function onInstallApp(session) {
    const {shop, accessToken} = session

    // Check if the store exists in deliveright
    // If not, the user needs to first fill out the form
    let retailer = undefined;
    try {
        retailer = await deliveright.getStore(shop);
    } catch (err) {
        console.error("Error getting store", err);
    }
    if (retailer) {
        await deliveright.updateStore(shop, {auth: {access_token: accessToken}})
        await createCarrier(session)
    }
}