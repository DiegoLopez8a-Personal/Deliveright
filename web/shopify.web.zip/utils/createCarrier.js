import config from "../config.js"
import shopify from "../shopify.js";
import isCarrierConfigured from "./isCarrierConfigured.js";

export default async function (session) {
	let carrier = await isCarrierConfigured(session)
	if (carrier) {
		console.log(
			`Carrier service creation was triggered, but it is already configured for store: ${session.shop}`
		);
		return;
	}
	const carrier_service = new shopify.api.rest.CarrierService({session: session, fromData: config.carrierService});
	await carrier_service.save({
		update: true,
	});
	console.log(
		`Carrier service created for store: ${session.shop} on ${config.carrierService.callback_url}`
	);
};
