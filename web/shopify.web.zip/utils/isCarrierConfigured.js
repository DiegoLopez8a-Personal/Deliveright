import config from "../config.js"
import shopify from "../shopify.js";

export default async function (session) {
    const carriers = (await shopify.api.rest.CarrierService.all({session}))?.data
    return carriers?.find?.((service) => service.name === config.carrierService.name);
};
