import dotenv from "dotenv"

dotenv.config({path: '../.env'});
let config = {};
const { HOST, DELIVERIGHT_HOST } = process.env;

config.deliverightApi = DELIVERIGHT_HOST;
config.host = HOST

// Shopify app scopes
config.shopifyAppScopes = [
  "read_products",
  "write_shipping",
  "read_shipping",
  "read_fulfillments",
  "write_fulfillments",
  "read_orders",
  "write_orders",
];

// Shopify carrier service settings
config.carrierService = {
  active: true,
  name: "Deliveright - White Glove Delivery",
  callback_url: `${HOST}/carrier`,
  service_discovery: true,
};

config.serviceLevels = {
  prcl: {
    service_name: "Parcel",
    description: "Parcel delivery service. No appointment or signature is required.",
    service_code: "prcl",
    currency: "USD",
  },
  willcall: {
    service_name: "Will Call",
    description: "Customer picks up from the local distribution warehouse.",
    service_code: "willcall",
    currency: "USD",
  },
  unattended: {
    service_name: "Unattended",
    description: "Unattended delivery to the customer's front door in the original packaging. No appointment scheduling or product setup.",
    service_code: "unattended",
    currency: "USD",
  },
  rocpa: {
    service_name: "Room of choice with Assembly",
    description: "Delivery of the products in the original packaging and assembly at the customer's home, including debris removal.",
    service_code: "rocpa",
    currency: "USD",
  },
  wg: {
    service_name: "White Glove Service",
    description: "White-Glove delivery and assembly at the customer home, including debris removal (assembly does not include wall mounting, electric hookups or burner element to the internal line, propane or gas lines)",
    service_code: "wg",
    currency: "USD",
  },

  thr: {
    service_name: "Threshold Service",
    description: "Delivering to the threshold of the customer's home (garage, front entrance etc.) or to the first dry area. Customer is responsible for unpacking and assembling",
    service_code: "thr",
    currency: "USD",
  },

  blnk: {
    service_name: "Blanket Wrap",
    description: "This service is the same as White Glove, but for items that are not packaged or crated. We will blanket wrap the item before shipping it to our terminal. We open the order in our terminal, inspect it, and apply minor touchups if needed</li> <li>We then blanket wrap and shrink-wrap the order and load it onto one of our home delivery trucks</li> <li>We call the customer 30 minutes before our arrival</li> <li>Upon arrival, we perform a walk-through to assess where the product(s) needs to be placed. We then bring the order to the room of choice and unpack the product(s)</li> <li>We will set up the order according to the customer's wishes, including 30 minutes of light assembly (excluding KDs). We always clean the area upon leaving so the customer can enjoy their new purchase right away!",
    service_code: "blnk",
    currency: "USD",
  },

  rocp: {
    service_name: "Room of Choice +",
    description: "We call the customer 30 minutes before our arrival. Upon arrival, we perform a walk-through to assess where the product(s) needs to be placed. We then bring the order to the room of choice and unpack the product(s). We always clean the area upon leaving so the customer can enjoy their new purchase right away! *The customer is responsible for assembling the order.",
    service_code: "rocp",
    currency: "USD",
  },

  roc: {
    service_name: "Room of Choice",
    description: "We call the customer 30 minutes before our arrival. Upon arrival, we perform a walk-through to assess where the product(s) needs to be placed. We then bring the order to the room of choice so when we leave the residence, your customer can unpack the product(s) and finish any setup or assembly (if needed). *The customer is responsible for unpacking and assembling the order.",
    service_code: "roc",
    currency: "USD",
  },

  b2b: {
    service_name: "Business to Business",
    description: "Delivering to the threshold of the customer's home (garage, front entrance etc.) or to the first dry area. Customer is responsible for unpacking and assembling",
    service_code: "b2b",
    currency: "USD",
  },

  curb: {
    service_name: "Curbside",
    description: "We call the customer 30 minutes before our arrival. We will leave the order outside the customer's home or apartment building. It is the customer's responsibility to bring the order inside the home. *The customer is responsible for unpacking and assembling the order",
    service_code: "curb",
    currency: "USD",
  },

  pick_consolidate: {
    service_name: "Pick & Consolidate",
    description: "Pickup from vendor for local consolidation",
    service_code: "curb",
    currency: "USD",
  },  

}

config.paymentStrategies = {
  PAID_BY_CUSTOMER: 0,
  PAID_BY_SHIPPER: 1,
  SPLIT: 2,
  FIXED: 3,
  ROUND_NEAREST_NUMBER: 4
}


export default config;
