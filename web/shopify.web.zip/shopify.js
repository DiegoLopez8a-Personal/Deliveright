// 👇 Este import debe ir antes de cualquier uso de shopifyApi()
import '@shopify/shopify-api/adapters/node';
 
import { shopifyApi, LATEST_API_VERSION } from '@shopify/shopify-api';
import { MongoDBSessionStorage } from '@shopify/shopify-app-session-storage-mongodb';
import { restResources } from "@shopify/shopify-api/rest/admin/2024-04";
import dotenv from 'dotenv';
import { shopifyApp } from '@shopify/shopify-app-express';

dotenv.config({path: "../.env"})
 
const sessionStorage = new MongoDBSessionStorage(
  process.env.MONGODB_URI,
  "shopify_sessions"
);
 
const api = shopifyApi({
  apiKey: process.env.SHOPIFY_API_KEY,
  apiSecretKey: process.env.SHOPIFY_API_SECRET,
  scopes: ['read_products'],
  hostName: process.env.HOST.replace(/^https:\/\//, ''),
  apiVersion: LATEST_API_VERSION,
  isEmbeddedApp: true,
  sessionStorage,
});

const shopify = shopifyApp({

  api: {

    apiKey: process.env.SHOPIFY_API_KEY,

    apiSecretKey: process.env.SHOPIFY_API_SECRET,

    hostName: process.env.HOST.replace(/^https:\/\//, ""),

    apiVersion: LATEST_API_VERSION,

    // restResources,

    isEmbeddedApp: true,

  },

  auth: {

    path: "/api/auth",

    callbackPath: "/api/auth/callback",

  },

  webhooks: {

    path: "/api/webhooks",

  },

  sessionStorage,

});
 
 
export default {api, shopify};